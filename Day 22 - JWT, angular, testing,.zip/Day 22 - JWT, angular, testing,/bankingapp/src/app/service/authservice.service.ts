import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BaseRouteReuseStrategy } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

   private _httpClient = inject(HttpClient);
   private apiurl:string = 'https://localhost:7133/Auth/Login';
  private _hasToken:boolean = false;

    login(credentials:any)
    {
      const cred = {
        "userName": credentials.userName,
        "password": credentials.password
      }
   //   console.log('Service : ' + credentials.userName + " " +  credentials.password);
        //make this call only if username and password are correct
      return this._httpClient.post<any>(this.apiurl,cred);
    }

    setToken(token:string)
    {
      //save the token in localstorage or session or cookie or temp, hidden or global variable
      localStorage.setItem('jwttoken',token);
    }

    getToken():string | null
    {
     return localStorage.getItem('jwttoken');    
      
    }

    removeToken():void
    {
      localStorage.removeItem('jwttoken');
    }

    // createAuthHeader()
    // {
    //   const token = this.getToken();
    //   return new HttpHeaders({
    //       'Authorization': token? token : ''
    //   });
    // }




}
