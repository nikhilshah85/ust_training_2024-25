import { Injectable, resource } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, Router, RouterStateSnapshot } from '@angular/router';
import { AuthserviceService } from './authservice.service';

@Injectable({
  providedIn: 'root'
})
export class GuardsService implements CanActivate{

  _authService = new AuthserviceService();

  canActivate(): boolean {
    
    const isTokenPresent = this._authService.getToken();
    
    if(isTokenPresent)
    {
      
      return true;
    }        
    
    return false;

  }

}
