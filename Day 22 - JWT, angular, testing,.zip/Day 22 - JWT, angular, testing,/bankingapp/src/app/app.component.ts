import { NgIf } from '@angular/common';
import { Component, Input, input } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthserviceService } from './service/authservice.service';
import { GuardsService } from './service/guards.service';
import { LoginComponent } from "./components/login/login.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, NgIf, LoginComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'bankingapp';
    myName = "Nikhil Sha";
  _guardService = new GuardsService();
  _authService = new AuthserviceService();
}
