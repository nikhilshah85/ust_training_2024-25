import { Component } from '@angular/core';

@Component({
  selector: 'app-transfer',
  imports: [],
  templateUrl: './transfer.component.html',
  styleUrl: './transfer.component.css'
})
export class TransferComponent {

}
