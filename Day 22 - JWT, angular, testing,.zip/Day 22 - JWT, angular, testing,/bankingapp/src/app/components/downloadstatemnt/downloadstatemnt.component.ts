import { Component } from '@angular/core';

@Component({
  selector: 'app-downloadstatemnt',
  imports: [],
  templateUrl: './downloadstatemnt.component.html',
  styleUrl: './downloadstatemnt.component.css'
})
export class DownloadstatemntComponent {

}
