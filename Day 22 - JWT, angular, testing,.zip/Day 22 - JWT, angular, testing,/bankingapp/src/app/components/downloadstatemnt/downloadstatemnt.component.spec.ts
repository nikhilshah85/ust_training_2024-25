import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadstatemntComponent } from './downloadstatemnt.component';

describe('DownloadstatemntComponent', () => {
  let component: DownloadstatemntComponent;
  let fixture: ComponentFixture<DownloadstatemntComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DownloadstatemntComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DownloadstatemntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
