import { Component, inject, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthserviceService } from '../../service/authservice.service';
@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

   _authService = new AuthserviceService();

    userLogin(formData: any) {
        
      console.log(formData);
      this._authService.login(formData).subscribe((result)=>{
        console.log('Component : ' + result.token);
        this._authService.setToken(result.token); //v imp
    
      })  

    }
    @Input() whoisUser ="";

    userLogOut()
    {
      this._authService.removeToken();
    }


}
