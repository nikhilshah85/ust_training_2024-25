import { Component } from '@angular/core';

@Component({
  selector: 'app-requestchequebook',
  imports: [],
  templateUrl: './requestchequebook.component.html',
  styleUrl: './requestchequebook.component.css'
})
export class RequestchequebookComponent {

}
