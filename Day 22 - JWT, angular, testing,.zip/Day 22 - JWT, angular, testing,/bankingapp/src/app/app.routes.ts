import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { DownloadstatemntComponent } from './components/downloadstatemnt/downloadstatemnt.component';
import { RequestchequebookComponent } from './components/requestchequebook/requestchequebook.component';
import { LoginComponent } from './components/login/login.component';
import { GuardsService } from './service/guards.service';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    {path:'home',component:HomeComponent},
    {path:'download',component:DownloadstatemntComponent,canActivate:[GuardsService]},
    {path:'request',component:RequestchequebookComponent,canActivate:[GuardsService]},
    {path:'login',component:LoginComponent},
];
