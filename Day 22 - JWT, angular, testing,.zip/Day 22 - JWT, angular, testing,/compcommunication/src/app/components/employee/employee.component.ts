import { Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-employee',
  imports: [],
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent {

  @Input() appTitle = ""; //this value is needed from parent

 @Output() empCity = new EventEmitter();
  myCity = "Mumbai";
  
  
  passDataToParent() {
    this.empCity.emit(this.myCity);  
    console.log('Passing data to parent component' + this.myCity);
  }



}
