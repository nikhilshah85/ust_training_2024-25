import { Component, EventEmitter, Output } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeComponent } from "./components/employee/employee.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, EmployeeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  appName = "Hello Employee Management Application"
  //this value needs to be displayed in a emp component
  //1. We do not want to create a new object of this component in other component
  //2. we do not want to include a service for this operaton as it gets heavy


  employeeBaseLocation = "";

  collectValueFromChild(val:any)
  {
    console.log(val);
    this.employeeBaseLocation = val
  }

  
}
