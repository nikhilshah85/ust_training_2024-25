import psutil

# Get CPU usage
cpu_usage = psutil.cpu_percent(interval=1)

# Get memory usage
memory = psutil.virtual_memory()
memory_usage = memory.percent

print(f"CPU Usage: {cpu_usage}%")
print(f"Memory Usage: {memory_usage}%")
