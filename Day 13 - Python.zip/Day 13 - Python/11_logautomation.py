def check_logs(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            if 'ERROR' in line:
                send_alert(line)

def send_alert(error_message):
    print(f"Alert: {error_message}")

check_logs('samplelogs.txt')
