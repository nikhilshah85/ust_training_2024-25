import schedule
import time

counter = 0;
def job(): 
    global counter;
    counter += 1;
    print('Hello From python ' +  str(counter));  

schedule.every(10).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)