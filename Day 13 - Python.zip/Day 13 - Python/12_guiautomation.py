import pyautogui
import time

time.sleep(2)  # Wait 2 seconds before executing

# Move mouse to position (x=100, y=100) and click
pyautogui.click(100, 100)

# Type a message
pyautogui.typewrite("Hello, this is an automation!")
