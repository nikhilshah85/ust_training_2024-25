import pandas as pd

# Create a DataFrame from a dictionary
data = pd.read_excel("Sales.xlsx")
# print(data.head())
# print(data.head(2))
# print(data.describe())
print(data["Product"])