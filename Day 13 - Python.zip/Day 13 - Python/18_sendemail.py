import smtplib    
sender_mail = 'nikhil.shah2008@gmail.com'    
receivers_mail = ['nikhilshah.net@hotmail.com']    
message = """From: Nikhil Shah %s  
To: My Self %s  
Subject: Sending SMTP e-mail using Python  
This is a test e-mail message.  
"""%(sender_mail,receivers_mail)    
try:    
   password = input('Enter the password');    
   smtpObj = smtplib.SMTP('gmail.com',587)    
   smtpObj.login(sender_mail,password)    
   smtpObj.sendmail(sender_mail, receivers_mail, message)    
   print("Successfully sent email")    
except Exception:    
   print("Error: unable to send email") 