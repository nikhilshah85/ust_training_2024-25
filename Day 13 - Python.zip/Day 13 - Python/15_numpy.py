import numpy as np

data = np.array([1, 2, 3])

print(data)

print(type(data))

data = np.array([[1, 2, 3], [4, 5, 6]])

print(data)

print(type(data))


data = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(data)


print(type(data.ndim))

data = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]], dtype=np.float64)
print(data)

print(type(data))