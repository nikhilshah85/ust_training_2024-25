import os
import shutil

source = 'orders/order2.txt'
destination = 'processed_orders/order2.txt'

shutil.move(source, destination)
os.renames(destination, 'processed_orders/dilivered.txt')

