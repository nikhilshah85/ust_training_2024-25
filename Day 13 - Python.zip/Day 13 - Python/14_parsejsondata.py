import pandas as pd

data = pd.read_json("postdata.json")
# print(data)
# print(data.to_json())


#lets convert json raw data to 2 dimensional array, rows and cols
data = pd.DataFrame(data); 
data.to_excel("postdata.xlsx")