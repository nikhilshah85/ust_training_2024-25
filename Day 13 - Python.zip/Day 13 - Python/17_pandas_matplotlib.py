import pandas as pd
import matplotlib.pyplot as plt

# data = {
#     'x':[1,2,3,4,5],
#     'y':[10,20,30,40,50]
# }

# df = pd.DataFrame(data)

# df.plot(x='x',y='y')
# plt.show()

data = pd.read_excel("Sales.xlsx")
df = pd.DataFrame(data);
# df.plot(x='Product',y='Amount')
plt.pie(df['Amount'],labels=df['Product'])
plt.show()

