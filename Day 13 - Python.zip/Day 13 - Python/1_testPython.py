print('Hello and welcome to the world of python');
guestName = input("Please enter your name: ");
print("Hello " + guestName + " nice to meet you!");