import os

response = os.system("ping google.com")
response = os.system("mkdir testfolder1")

if response == 0:
    print("Host is reachable")
else:
    print("Host is unreachable")
