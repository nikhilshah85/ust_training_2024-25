import os
import shutil

source = 'orders/'
destination = 'processed_orders/'

for filename in os.listdir(source):
    if filename.endswith('.json'):
        shutil.move(source + filename, destination + filename)