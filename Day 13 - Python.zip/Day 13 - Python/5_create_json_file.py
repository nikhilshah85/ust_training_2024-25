import json

#This is how we create functions in python
def createJsonFile(filename,samplejsondata):
    with open(filename,'w') as f:
        json.dump(samplejsondata,f);
    print("JSON file created successfully");

samplejsondata = {
    "name": "John",
    "age": 30,
    "city": "New York"
}
#call the function
source = 'orders/sampledata.json'
createJsonFile(source,samplejsondata);