import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [10,20,5,40,90]

plt.title("My first graph")
plt.xlabel("Month axis")
plt.ylabel("Sales")
# plt.plot(x, y,linestyle='-', marker='o', color='red')
# plt.scatter(x, y,linestyle='-', marker='o', color='red')
# plt.bar(x,y)
a = ["JAN","FEB","MAR","APR","MAY"]
b = [10,20,5,40,90]
plt.pie(b,labels=a)

plt.show()