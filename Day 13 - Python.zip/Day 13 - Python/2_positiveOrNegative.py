userNumber = input("Enter A number of your choice: ");

if (int(userNumber) > 0 and int(userNumber) < 100):
    print("Your number is positive but less than 100, plz imrove");
elif (int(userNumber) > 100):
    print("Your number is positive and greater than 100");
    print('hello');
else:
    print("Your number is negative");
    print('Thank you for using my code');

