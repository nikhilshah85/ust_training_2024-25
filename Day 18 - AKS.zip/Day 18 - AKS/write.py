import yaml

# Python data to write to YAML
data = {
    'name': 'Jane Doe',
    'age': 28,
    'is_active': True,
    'address': {
        'street': '456 Elm St',
        'city': 'Othertown',
        'zip': 67890
    },
    'hobbies': ['Swimming', 'Photography', 'Cycling']
}

# Write data to YAML file
with open("result.yaml", "w") as file:
    yaml.dump(data, file, default_flow_style=False)

print("Data has been written to result.yaml")
