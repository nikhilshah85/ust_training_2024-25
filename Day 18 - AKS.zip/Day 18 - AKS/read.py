import yaml

# Read YAML file
with open("info.yml", "r") as file:
    data = yaml.safe_load(file)

# Print data
print(data)
