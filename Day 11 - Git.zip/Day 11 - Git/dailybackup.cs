using System;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ust_training
{
    public class dailybackup
    {
        private readonly ILogger _logger;

        public dailybackup(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<dailybackup>();
        }

        [Function("dailybackup")]
        public void Run([TimerTrigger("0 */2 * * * *")] TimerInfo myTimer)
        {
            //perform any operation here of your choice
            //back up
            //send notification
            //if time is between 6 and 8, raise the car fare
            //if month is dec, increase the price of all products by 10%
            _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            
            if (myTimer.ScheduleStatus is not null)
            {
                _logger.LogInformation($"Next timer schedule at: {myTimer.ScheduleStatus.Next}");
            }
        }
    }
}
