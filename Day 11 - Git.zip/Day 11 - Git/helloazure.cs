using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ust.training
{
    public class helloazure
    {
        private readonly ILogger<helloazure> _logger;

        public helloazure(ILogger<helloazure> logger)
        {
            _logger = logger;
        }

        [Function("helloazure")]
        public IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request."); //this will do the logging task -file log

    //can connect to a database, pull the data and give it to the user
    //check which browser, location, ipaddress user is coming from, make a decision and process

            List<string> technologies = new List<string>(){
                "C#",
                "Java",
                "Python",
                "Javascript",
                "C++",
                "Go",
                "Rust",
                "Swift",
                "Kotlin",
                "Ruby",
                "PHP",
                "R",
                "SQL",
                "PL/SQL",
                "HTML"
            };            

            return new OkObjectResult(technologies);
        }
    }
}

