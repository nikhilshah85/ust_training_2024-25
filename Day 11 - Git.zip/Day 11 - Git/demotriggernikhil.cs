using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ust_training
{
    public class demotriggernikhil
    {
        private readonly ILogger<demotriggernikhil> _logger;

        public demotriggernikhil(ILogger<demotriggernikhil> logger)
        {
            _logger = logger;
        }

        [Function("demotriggernikhil")]
        public IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            return new OkObjectResult("Welcome to Azure Functions!");
        }
    }
}
